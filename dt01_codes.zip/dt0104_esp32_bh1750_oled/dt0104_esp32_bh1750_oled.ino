//https://github.com/olikraus/u8g2/wiki
#include<Wire.h>
#include<U8g2lib.h>
#include<BH1750.h>
#define BAUDRATE 115200

U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);

#define ROW_1 8
#define ROW_2 18
#define COL_START 0

BH1750 light_sensor;

void setup() {
Serial.begin(BAUDRATE);

Wire.begin();
u8g2.begin();
light_sensor.begin();

u8g2.clearBuffer();
u8g2.setFont(u8g2_font_ncenB08_tr); // choose a suitable font
u8g2.setCursor(COL_START, ROW_1);
u8g2.print("Display test "); 
u8g2.sendBuffer();
}

long p_millis = 0;
int i=0;
String message;
#define HR_MODE_DELAY 1000 // High Resolution Mode min.120[ms]

void loop() {
if(millis() - p_millis > HR_MODE_DELAY) {
 double lux = light_sensor.readLightLevel();
 message = "Light intensity" + String(lux);
 Serial.println(message + "[lx]");
 u8g2.setCursor(COL_START, ROW_2);
 u8g2.print("Light "); u8g2.print(lux); u8g2.print("[lx]"); 
 u8g2.sendBuffer();
 u8g2.clearBuffer();
 p_millis = millis();
}
}
