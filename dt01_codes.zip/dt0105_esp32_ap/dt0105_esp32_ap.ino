#define BAUDRATE 115200
#define LED 2
#define BUTTON 17

#include <WiFi.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>

long p_millis=0;

// SSID
const char* ssid = "Light_switch_net";
// Password/Empty Password=Open AP   
const char* password = "";           

bool switch_state = false;
int light_intensity = 0;
int light_intensityR = 0;

ICACHE_RAM_ATTR void changeState() {
  switch_state = !switch_state;
  Serial.println(switch_state);
  digitalWrite(LED,switch_state);
}

void setup() {
 Serial.begin(BAUDRATE);
 WiFi.mode(WIFI_AP);
 WiFi.softAP(ssid, password);
 delay(1000);  
 Serial.print("\nIP Address: ");   Serial.println(WiFi.softAPIP());    
 pinMode(LED,OUTPUT);
 attachInterrupt(digitalPinToInterrupt(BUTTON),changeState,RISING);
}

#define MAIN_LOOP_DELAY 1000

void loop() {
  if(millis() - p_millis > MAIN_LOOP_DELAY) {
   };
}


