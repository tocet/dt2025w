// https://randomnerdtutorials.com/esp32-useful-wi-fi-functions-arduino/
#include <WiFi.h>
#define BAUDRATE 115200

const char* ssid = "Laboratorium-IoT";
const char* pass = "IoTL@bolatorium";

void setup() {
  Serial.begin(BAUDRATE);
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, pass);
  Serial.print("Connecting to ");   Serial.print(ssid);
  Serial.print("with password ");   Serial.println(pass);
  Serial.print("Start connection .");
  while (WiFi.status() != WL_CONNECTED) {
    Serial.print(".");
    switch (WiFi.status()) {
      case WL_IDLE_STATUS:
        Serial.println("Wi-Fi is in process of changing between statuses");
        break;

      case WL_NO_SSID_AVAIL:
        Serial.println("Configured SSID cannot be reached");
        break;

      case WL_CONNECT_FAILED:
        Serial.println("Connection failed");
        break;

      case WL_CONNECTION_LOST:
        Serial.println("Connection is lost");
        break;

      case WL_DISCONNECTED:
        Serial.println("Disconnected from a network");
        break;

      default:
        Serial.println("Unknown WiFi status message");
        break;
    }
    delay(250);
  }

  Serial.print("\nESP32 board IP: "); Serial.println(WiFi.localIP());
  WiFi.setAutoReconnect(true);    // automatically reconnect to the
  WiFi.persistent(true);          // previously connected AP

  Serial.setDebugOutput(true);
  WiFi.printDiag(Serial);

  Serial.printf("Connection status: %d\n", WiFi.status());
  Serial.print("RRSI: ");  Serial.println(WiFi.RSSI());
}

void loop() {
}
